const images = [
    'images/image-1.jpg',
    'images/image-2.jpg',
    'images/image-3.jpg',
    'images/image-4.jpg'
];

// Index to keep track of the current image
let currentIndex = 0;

// Function to show the current slide
function showSlide(index) {
    const slideImage = document.getElementById('slide');
    slideImage.src = images[index];
}

// Function to show the next slide
function nextSlide() {
    currentIndex = (currentIndex + 1) % images.length;
    showSlide(currentIndex);
}

// Function to show the previous slide
function previousSlide() {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    showSlide(currentIndex);
}

// Initial display of the first slide
showSlide(currentIndex);
