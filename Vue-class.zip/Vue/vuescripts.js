// Create a new Vue instance
new Vue({
    el: '#my-simple-app',
    data: {
        message: 'Hello, I am a Vue App!',
        person:{
            name:"Fereshteh Karimi",
            position:"Admin",
            number:"+98915xxxxxxx",
            picture:"image/hanieh-admin.jpg"
        },
        fancycars:[
            {
                name:"Mazarati",
                pic:"image/mazarati.png"
            },
            {
                name:"BMW",
                pic:"image/bmw.jpg"
            },
            {
                name:"Genesis",
                pic:"image/genesis.jpg"
            },
            {
                name:"Ferari",
                pic:"image/ferrari.jpeg"
            },
            {
                name:"Santafe",
                pic:"image/santafe.jpg"
            }            
        ]

    },
    methods:{

    }
    });
  