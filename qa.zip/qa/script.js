// Get references to form elements
const form = document.getElementById('qaForm');
const questionInput = document.getElementById('questionInput');
const answerInput = document.getElementById('answerInput');
const qaList = document.getElementById('qaList');

// Function to add a question and answer
function addQA(question, answer) {
    // Create a new div for the question
    const qaDiv = document.createElement('div');
    qaDiv.className = 'question';
    
    // Create an element for the question text
    const questionElement = document.createElement('h3');
    questionElement.textContent = question;
    
    // Create an element for the answer text
    const answerElement = document.createElement('p');
    answerElement.className = 'answer';
    answerElement.textContent = answer;
    
    // Create a delete button
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.style.backgroundColor = '#d9534f';
    deleteButton.style.color = 'white';
    deleteButton.style.border = 'none';
    deleteButton.style.padding = '5px 10px';
    deleteButton.style.marginTop = '10px';
    deleteButton.style.cursor = 'pointer';
    deleteButton.style.borderRadius = '4px';

    // Add event listener to the delete button
    deleteButton.addEventListener('click', function() {
        qaList.removeChild(qaDiv);
    });

    // Append the question, answer, and delete button to the div
    qaDiv.appendChild(questionElement);
    qaDiv.appendChild(answerElement);
    qaDiv.appendChild(deleteButton);
    
    // Add the new question and answer to the list
    qaList.appendChild(qaDiv);
}

// Event listener for the form submission
form.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting normally
    
    // Get the values from the input fields
    const question = questionInput.value;
    const answer = answerInput.value;
    
    // Add the question and answer to the page
    addQA(question, answer);
    
    // Clear the input fields
    questionInput.value = '';
    answerInput.value = '';
});
